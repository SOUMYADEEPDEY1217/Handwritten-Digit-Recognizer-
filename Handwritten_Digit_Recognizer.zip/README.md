# Handwritten Digit Recognizer

This project uses a Convolutional Neural Network (CNN) to recognize handwritten digits using the MNIST dataset.

## Requirements
- Python 3.x
- TensorFlow or PyTorch
- matplotlib

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the model: `python digit_recognizer.py`

## Dataset
MNIST dataset is downloaded automatically via libraries like TensorFlow or torchvision.
